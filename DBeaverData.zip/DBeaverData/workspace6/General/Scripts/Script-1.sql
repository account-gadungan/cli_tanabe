select top 100 * from CHECKINOUT c

SELECT top 100 * from sf_attend_log

select * from TTADATTENDANCETEMP t;