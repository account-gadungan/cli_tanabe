select * from tpympayallowdeduct t where allowdeduct_formula like '%@altit%';
select * from tpympayallowdeduct t where allowdeduct_formula like '%@alfam%';

select * from tpydempallowdeduct t where allowdeduct_formula like '%@sal%';