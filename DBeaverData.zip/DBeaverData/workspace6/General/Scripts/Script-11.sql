
select * from (
  select table_name, ExtractValue(record_key,'/RECORDKEY/emp_id') pkey,
  activity_type, modified_date, 
  (select full_name from view_employee where emp_no = m.modified_by) modified_by_,
  field_name, old_value, new_value
  -- ,field_type
  -- ,record_key
  from TCLLMLOGACTIVITY m
  inner join TCLLdLOGACTIVITY d on d.log_header_id = m.log_header_id
  where table_name like '%tpydempsalaryparam%'
	and d.field_name like 'taxstatus'
) x
-- where pkey = 'CTL20190113057';
order by modified_date desc;

select * from tpydempsalaryparam t where emp_id = 'DO183455';
select * from teodemploymenthistory t where emp_id = 'DO183455';
select * from tpydprocmtdh t where emp_id = 'DO183455';

select * from tcltusersharing where user_name = '51808351'; -- user_id
update tcltusersharing set status = 1 where seq_id = 67 and user_name = '51808351';  


select * from tclmuser t ;
select * from teomemppersonal t2  ;

select 
emp_id, emp_no, full_name, u.user_name, 
start_date, end_date,
grade_code, grade_order, employ_code, cost_code,
position_id, pos_code,pos_name_en, pos_level, parent_path, 
dept_id,dept_code,
jobstatuscode, jobtitle_code, grade_category, worklocation_code,
is_main, empcompany_status,
gender, v.user_id, taxno, status, lastreqno, email, photo, phone, birthplace, birthdate, maritalstatus, address, company_id,   
spv_parent, spv_pos, spv_path, spv_level, mgr_parent, mgr_pos, mgr_path, mgr_level
-- personalarea_code, personalsubarea_code, payrollarea_code, employeegroup_code, customfield1
from view_employee v
inner join tclmuser u on u.user_id = v.user_id
-- where full_name like '%%'
-- where emp_id like '%%'
where emp_no like '%51910593%'
-- where user_id like '%%'
-- where user_name like '%%';

select * from ttadattendancetemp t where attendanceid = '51910593';


select *,
(select emp_no from view_employee where emp_id = s.emp_id) as emp_no 
from ttadempshiftgroup s 
where always_present = 'Y';

select * from tpymtaxparam t where param_code like '%annualize%';


  

select count(*) from ttadattendancetemp t
where attend_date > date_add(now(),interval -6 month);



select * from ttadattendancetemp 
where attend_date < date_add(now(),interval -3 month);

select date_add(now(),interval -3 month); 

select * from tsfmaccess t ;

select * from trcmfiltercriteria t ;

select * from view_employee ve where status = 1;

select count(*) from view_employee ve where status = 1;

select distinct 
status,
v.emp_id,
emp_no, full_name,  
start_date, 
employ_code, 
(select jobtitle_name_en from teomjobtitle where jobtitle_code = v.jobtitle_code) jobtitle, 
grade_code, 
worklocation_code,
(select worklocation_name from teomworklocation where worklocation_code = v.worklocation_code) worklocation,
end_date
,customfield4,
customfield5,
compbank_code,
bank_account,
v.parent_path,
case right(left(v.parent_path,11),4) 
	when '1837' then 'Operation'
	when '3096' then 'Engineering'
	else 'Director'
end
from view_employee v
inner join tclmuser u on u.user_id = v.user_id
inner join teomposition p on p.position_id = v.position_id 
left outer join teodempcustomfield c on v.emp_id = c.emp_id 
left outer join tpydempbankperiod b on b.emp_id = v.emp_id
where status = 1 
or (end_date between '2020-12-11' and '2021-01-15') ;


select * from tpydempbankperiod where emp_id = 'DO180478';

select * from teodempcustomfield t ;
select * from tpydempbankperiod;

select * from teomposition t where position_id in (
select distinct right (parent_path ,4)from teomposition t where org_level = 'DIV'
);

select distinct right(left(parent_path,11),4) from teomposition t where org_level = 'DIV';

select parent_path from teomposition t where org_level = 'DIV';
select * from teomposition t where org_level = 'DIV';

select distinct table_name from information_schema.tables 
where table_name like '%bank%';
-- and table_schema like '%dev';

select * from tpymbank;
select * from tpymbankgroup;
;


select 
emp_id, emp_no, full_name, u.user_name, 
start_date, end_date,
grade_code, grade_order, employ_code, cost_code,
position_id, pos_code,pos_name_en, pos_level, parent_path, 
dept_id,dept_code,
jobstatuscode, jobtitle_code, grade_category, worklocation_code,
is_main, empcompany_status,
gender, v.user_id, taxno, status, lastreqno, email, photo, phone, birthplace, birthdate, maritalstatus, address, company_id,   
spv_parent, spv_pos, spv_path, spv_level, mgr_parent, mgr_pos, mgr_path, mgr_level
-- personalarea_code, personalsubarea_code, payrollarea_code, employeegroup_code, customfield1
from view_employee v
inner join tclmuser u on u.user_id = v.user_id
where full_name like '%sugiha%'
-- where emp_no like '%52011404%'
-- where user_id like '%%'
-- where user_name like '%%';

select * from ttadattendancetemp t where attendanceid = '52011404';