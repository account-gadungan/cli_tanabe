SELECT P.PROCMTDH_ID, P.PERIOD_CODE, P.PAYDATE, P.TAXSTATUS, P.NUMDEPENDENT, P.GRADE_CODE,p.emp_id 
-- (select pos_name_en from teomposition where position_id = P.position_id ) as POS_NAME, E.EMP_ID, E.EMP_NO, E.FULL_NAME, E.address
,(select sum(SF2356896(dd.COMP_VALUE_PERIOD, "A8B48C1D0BBAB3A3","10011010100010011011", P.emp_id )) AS COMP_VALUE
from tpydprocmtdd dd
inner join tpydprocmtdh dh on dh.procmtdh_id = dd.procmtdh_id
where dh.emp_id = p.emp_id and dh.procmtdh_id = p.procmtdh_id and dd.allowdeducttype ="A") as allowance
-- (select sum(SF2356896(dd.COMP_VALUE_PERIOD, "A8B48C1D0BBAB3A3","10011010100010011011", e.emp_id)) AS COMP_VALUE
-- from tpydprocmtdd dd
-- inner join tpydprocmtdh dh on dh.procmtdh_id = dd.procmtdh_id
-- where dh.emp_id = p.emp_id and dh.procmtdh_id = p.procmtdh_id and dd.allowdeducttype ="D") as deductions
FROM TPYDPROCMTDH AS P
-- JOIN VIEW_EMPLOYEE AS E ON (E.EMP_ID = P.EMP_ID)
WHERE 1=1
-- and P.PERIOD_CODE = "ECAH1"
-- AND YEAR(P.PAYDATE) = 2020
-- AND MONTH(P.PAYDATE) = 1
-- AND P.EMP_ID IN ("DO203023")
-- ORDER BY E.FULL_NAME

SELECT P.PROCMTDH_ID, P.PERIOD_CODE, P.PAYDATE, P.TAXSTATUS, P.NUMDEPENDENT, P.GRADE_CODE,
(select pos_name_en from teomposition where position_id = P.position_id ) as POS_NAME, E.EMP_ID, E.EMP_NO, E.FULL_NAME, E.address
-- ,(select sum(SF2356896(dd.COMP_VALUE_PERIOD, "A8B48C1D0BBAB3A3","10011010100010011011", e.emp_id )) AS COMP_VALUE
-- from tpydprocmtdd dd
-- inner join tpydprocmtdh dh on dh.procmtdh_id = dd.procmtdh_id
-- where dh.emp_id = p.emp_id and dh.procmtdh_id = p.procmtdh_id and dd.allowdeducttype ="A") as allowance,
-- (select sum(SF2356896(dd.COMP_VALUE_PERIOD, "A8B48C1D0BBAB3A3","10011010100010011011", e.emp_id)) AS COMP_VALUE
-- from tpydprocmtdd dd
-- inner join tpydprocmtdh dh on dh.procmtdh_id = dd.procmtdh_id
-- where dh.emp_id = p.emp_id and dh.procmtdh_id = p.procmtdh_id and dd.allowdeducttype ="D") as deductions
FROM TPYDPROCMTDH AS P
JOIN VIEW_EMPLOYEE AS E ON (E.EMP_ID = P.EMP_ID)
WHERE 1=1
-- and P.PERIOD_CODE = "ECAH1"
-- AND YEAR(P.PAYDATE) = 2020
-- AND MONTH(P.PAYDATE) = 1
-- AND P.EMP_ID IN ("DO203023")
ORDER BY E.FULL_NAME

select SF2356896(COMP_VALUE_period, "A8B48C1D0BBAB3A3","10011010100010011011","DO202833")
from tpydprocmtdd where procmtdh_id = "MTD_23338_DO202833_EAMH1_20115";

select *
from tpydprocmtdd where procmtdh_id = 'MTD_23338_DO202833_EAMH1_20115';

select * from view_employee where emp_id = 'DO202833';