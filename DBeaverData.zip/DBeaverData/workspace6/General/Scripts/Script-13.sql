select * from view_employee where emp_id in( 
select distinct emp_id from tctdtimesheetcosting t
where 
tanggal > '2020-01-21' and 
tanggal < '2020-08-20' and
t.emp_id not in (select emp_id from tpydprocmtdh where paydate = '2020-02-25'))

select * from tctmwebservice t ;

select * from TCTDTIMESHEETATTENDANCE;
select * from TCTDTIMESHEETcosting;
select * from TCTDTIMESHEETcosting_log;


select full_name, emp_no from view_employee ve 
where emp_id in (
select emp_id from tpydprocmtdh t 
where period_code = 'tugaskarya' 
and month(paydate)= 7
order by paydate desc
) and (parent_path like '%4378%'
        or parent_path like '%4445%' 
        or parent_path like '%4500%');
        
select position_id,pos_name_en,pos_code 
from   teomposition
where position_id in ('4378','4500','4445');


select distinct table_name from information_schema.tables 
where table_name like '%company%';
-- and table_schema like '%dev';

select * from tclcappcompany where field_code = 'ts_organization';

select * from tpydprocmtdh t ;
select * from tpydprocmtdd t ;
select * from tpydprocytdd t ;
select * from tpydprocytdh t ;

-- delete from tpydprocmtdd;
-- delete from tpydprocmtdh;
-- delete from tpydprocytdd;
-- delete from tpydprocytdh;

select *
from (select emp_id,effectivedt,emp_no from teodemploymenthistory
	where employmentstatus_code = 'permanent'
	and emp_id = 
	order by effectivedt 
	limit 1) as t
and effectivedt <= date_sub("2020-01-25",interval 1 year)
and (
date_format(effectivedt, '%m-%d') between 
date_format((select salarystartdate from ttadattintf where paydate="2020-01-25" limit 1), '%m-%d') and 
date_format((select salarystartdate from ttadattintf where paydate="2020-01-25" limit 1), '%m-31') or
date_format(effectivedt, '%m-%d') between 
date_format((select salaryenddate from ttadattintf where paydate="2020-01-25" limit 1), '%m-01') and 
date_format((select salaryenddate from ttadattintf where paydate="2020-01-25" limit 1), '%m-%d'))
and mod(year("2020-01-25")-year(effectivedt),6) != 0 
and (mod(year("2020-01-25")-year(effectivedt),8) != 0 or year("2020-01-25")-year(effectivedt) = 8)
order by effectivedt desc ;

select * from tctsp;

select * from tctmccpattern t ;

show table tctmccpattern;

alter table tctmccpattern modify pattern text;

select
	req.request_no,
	(
	select
		full_name
	from
		teomemppersonal
	where
		emp_id = req.requestfor) as emp_name,
	(
	select
		purpose_name_en
	from
		ttamondutypurposetype
	where
		purpose_code = req.purpose_code) as purpose_name,
	case
		when (
		select
			name_en
		from
			ttamoddestination
		where
			code = req.departure) is null then req.departure
		else (
		select
			name_en
		from
			ttamoddestination
		where
			code = req.departure)
	end as departure_name,
	req.requestdate,
	st.approved_list,
	st.approved_data,
	st.modified_date as approved_date,
	req.onduty_startdate as departure_date,
	req.onduty_enddate as return_date,
	req.charge_code,
	req.totalvalue,
	(
	select
		tpymbank.bank_name
	from
		tpydempbank
	inner join tpymbank on
		tpydempbank.bank_code = tpymbank.bank_code
	where
		emp_id = req.requestfor
	limit 1) as bank_name,
	(
	select
		account_name
	from
		tpydempbank
	where
		emp_id = req.requestfor
	limit 1) as account_name,
	(
	select
		bank_account
	from
		tpydempbank
	where
		emp_id = req.requestfor
	limit 1) as bank_account,
	'0' as flagpl
from
	ttadondutyrequest req
left join tcltrequest st on
	st.req_no = req.request_no
where
	req.company_id = 13852
	and req.purpose_code in ('DETASERING', 'KESEHATAN_DN', 'KESEHATAN_LN', 'KONSINYERING', 'MOBDEMOB', 'MUTASI', 'PENDIDIKAN', 'PERJALANANDINAS_LN', 'SPPDBIASA', 'SPPD_Proyek_Medan_Review_Desain', 'TEMPORARYLEAVE', 'TLK')
	and st.status in (3, 9)
	-- 3=fully approved, 9=closed
	and (req.request_no not in (
	select
		distinct l.request_no
	from
		tctsppdjournallog l
	where
		status like '%succeed%')
	or req.request_no in (
	select
		l.request_no
	from
		tctsppdjournallog l
	where
		status like '%succeed%'
	group by
		l.request_no
	having
		date(max(l.created_date)) = '2020-11-09') )
union
-- JOIN ALL DATA

-- DATA ONDUTY REQUEST PERSON LUAR
 select
	req.request_no,
	(
	select
		name
	from
		tctmondutypersonluar
	where
		PersonID = req.requestfor) as emp_name,
	(
	select
		purpose_name_en
	from
		ttamondutypurposetype
	where
		purpose_code = req.purpose_code) as purpose_name,
	case
		when (
		select
			name_en
		from
			ttamoddestination
		where
			code = req.departure) is null then req.departure
		else (
		select
			name_en
		from
			ttamoddestination
		where
			code = req.departure)
	end as departure_name,
	req.requestdate,
	st.approved_list,
	st.approved_data,
	st.modified_date as approved_date,
	req.onduty_startdate as departure_date,
	req.onduty_enddate as return_date,
	req.charge_code,
	req.totalvalue,
	(
	select
		tpymbank.bank_name
	from
		tctmondutypersonluar
	inner join tpymbank on
		tctmondutypersonluar.bank_code = tpymbank.bank_code
	where
		PersonID = req.requestfor
	limit 1) as bank_name,
	(
	select
		account_name
	from
		tctmondutypersonluar
	where
		PersonID = req.requestfor
	limit 1) as account_name,
	(
	select
		bank_account
	from
		tctmondutypersonluar
	where
		PersonID = req.requestfor
	limit 1) as bank_account,
	'1' as flagpl
from
	tctdondutyrequestpl req
left join tcltrequest st on
	st.req_no = req.request_no
where
	req.company_id = 13852
	and req.purpose_code in ('DETASERING', 'KESEHATAN_DN', 'KESEHATAN_LN', 'KONSINYERING', 'MOBDEMOB', 'MUTASI', 'PENDIDIKAN', 'PERJALANANDINAS_LN', 'SPPDBIASA', 'SPPD_Proyek_Medan_Review_Desain', 'TEMPORARYLEAVE', 'TLK')
	and st.status in (3, 9)
	-- 3=fully approved, 9=closed
	and (req.request_no not in (
	select
		distinct l.request_no
	from
		tctsppdjournallog l
	where
		status like '%succeed%')
	or req.request_no in (
	select
		l.request_no
	from
		tctsppdjournallog l
	where
		status like '%succeed%'
	group by
		l.request_no
	having
		date(max(l.created_date)) = '2020-11-09') )
		

		select * from tctsppdjournallog order by created_date desc limit 10;
		
select * from tsfmreserveword t where word in ('TS_EMPLOYEE','CUTITAHUNAN') order by created_date desc;

select field_value
from   tclcappcompany
where field_code = 'ts_organization'
limit 1;


select position_id from teomposition where pos_code in 
(	
	select cast (field_value as int)
	from tclcappcompany t 
	where field_code like 'ts_organization'
);

--     CREATE TABLE clients (
--       id SERIAL,
--       fullname VARCHAR(255),
--       address TEXT,
--       PRIMARY KEY (id)
--     );
--    INSERT INTO clients (id, fullname, address) VALUES
--        (1, 'Mark Johnson', '2113 Jackson Street,Apt. B,Erie,CA,510'),
--     (2, 'Sasha Smith', '123 Main Street,,Erie,CA,512');
-- 
--        SELECT fullname, SUBSTRING_INDEX(address, ',', 8) FROM clients;
--       select * from clients;
select * from teomposition where pos_code in (1131,1132,1133);
select * from teomposition where 1=1 
AND ((parent_path like '%4378%' OR parent_path like '%4445%' OR parent_path like '%4500%') and pos_flag = 2);
select field_value from tclcappcompany t where field_code like 'ts_organization';

select 
emp_id, emp_no, full_name, u.user_name, 
start_date, end_date,
grade_code, grade_order, employ_code, cost_code,
position_id, pos_code,pos_name_en, pos_level, parent_path, 
dept_id,dept_code,
jobstatuscode, jobtitle_code, grade_category, worklocation_code,
is_main, empcompany_status,
gender, v.user_id, taxno, status, lastreqno, email, photo, phone, birthplace, birthdate, maritalstatus, address, company_id,   
spv_parent, spv_pos, spv_path, spv_level, mgr_parent, mgr_pos, mgr_path, mgr_level
-- personalarea_code, personalsubarea_code, payrollarea_code, employeegroup_code, customfield1
from view_employee v
inner join tclmuser u on u.user_id = v.user_id
where full_name like '%haitami%'
-- where emp_id like '%%'
-- where emp_no like '%%'
-- where user_id like '%%'
-- where user_name like '%%';

select * from teomposition t where position_id = '4419';

select * from tctdtimesheetattendance t where nama_pegawai like '%betty%' order by ts_date desc;

select * from ttadattendance t2 where emp_id = 'DO172407' order by shiftstarttime desc;

SELECT * FROM (
SELECT E.full_name emp_name
,E.emp_id
,EC.emp_no
FROM TEOMEmpPersonal E INNER
JOIN TEODEmpCompany EC ON E.emp_id=EC.emp_id
INNER JOIN TEODEmppersonal EO on EO.emp_id = E.emp_id
INNER JOIN TEOMPOSITION POS on POS.position_id = EC.position_id and POS.company_id = EC.company_id
WHERE
1=1
AND EC.company_id=13852
AND ((parent_path like '%4378%' OR parent_path like '%4445%' OR parent_path like '%4500%') and pos_flag = 2)
AND (EC.end_date >= getdate() OR EC.end_date IS NULL OR EC.status = '1')
) tbl1
WHERE 1=1
ORDER BY emp_name asc;

select * from TEOMEmppersonal ;
select * from tpympayperiod t ;

select ts.ts_id, c.emp_id, p.position_id, ts.username, ts.ts_date, ts.duration, ts.uploadstatus
from TCTDTIMESHEETATTENDANCE ts
left join teodempcustomfield c on c.customfield5 = ts.username
left join teodempcompany p on p.emp_id = c.emp_id
where ts.company_id = 13852
and ts.ts_date >= {d '2020-08-21'}
and ts.ts_date < {d '2020-09-22'}
and c.emp_id = 'DO172407'
order by ts.ts_date;

select *
from TCTDTIMESHEETATTENDANCE ts
where ts.company_id = 13852
and ts.ts_date >= {d '2020-08-21'}
and ts.ts_date < {d '2020-09-22'}
and username = 'rizal'
order by ts.ts_date;

select count(*)
from TCTDTIMESHEETATTENDANCE ts
where ts.company_id = 13852
and ts.ts_date >= {d '2020-08-21'}
and ts.ts_date < {d '2020-09-22'}
order by ts.ts_date;


-- select * from TCTDTIMESHEETATTENDANCE ;

-- select * from ttadattendance t where emp_id = 'DO172407' order by shiftstarttime desc;
select * from tctdtimesheetcosting_log  order by created_date desc;
select * from TCTDTIMESHEETATTENDANCE_LOG order by created_date desc;
select * from TCTDTIMESHEETATTENDANCE where log_id = 25;
show create table TCTDTIMESHEETATTENDANCE;
select * from TCTDTIMESHEETCOSTING;
select * from TCTDINVALIDTIMESHEET where log_id = '75';

-- set @emp_id='DO1911669';
-- set @emp_id='DO170921'; -- indri
set @emp_id = 'DO172407'; -- betty
set @emp_id = 'DO173237'; -- aan

-- set @emp_id = 'DO172449';
-- set @start_time = '2020-09-21 00:00:00';
-- set @end_time = '2020-10-20 00:00:00';
set @start_time = '2020-08-21 00:00:00';
set @end_time = '2020-09-20 00:00:00';

select * from ttadattendance t where emp_id = @emp_id 
and shiftstarttime >= @start_time
and shiftstarttime < @end_time 
order by shiftstarttime desc;

select * from ttadattendance t where shiftstarttime > '2020-09-29' and emp_id = @emp_id;

select * from TTADATTSTATUSDETAIL t where attend_id in 
(
	select attend_id from ttadattendance t where emp_id = @emp_id 
	and shiftstarttime >= @start_time
	and shiftstarttime < @end_time
	order by shiftstarttime desc
);

select attend_id , group_concat(attend_code) as 'result' from TTADATTSTATUSDETAIL t where attend_id in 
(
	select attend_id from ttadattendance t where emp_id = @emp_id 
	and shiftstarttime >= @start_time
	and shiftstarttime < @end_time
	order by shiftstarttime desc
)group by attend_id ; 

select *
from TCTDTIMESHEETATTENDANCE ts
where ts.company_id = 13852
and ts.ts_date >= @start_time
and ts.ts_date < @end_time
and username = 'betty.yulita'
order by ts.ts_date;

select *
from TCTDTIMESHEETATTENDANCE ts
where ts.company_id = 13852
and ts.ts_date >= @start_time
and ts.ts_date < @end_time
and username = 'aan.setyawan'
order by ts.ts_date;

select * from TCTDTIMESHEETATTENDANCE where nama_pegawai like '%betty%' order by ts_date desc;

select attend_id , group_concat(attend_code) as 'attend_code' from TTADATTSTATUSDETAIL where attend_id = 'ATD-2020-016474';


select * from teodempcompany where emp_id = 'DO172516';
select * from TCTDEMPABS5LOG;
truncate table TCTDEMPABS5LOG;

select attend_code , remark from ttadattendance 
where 1=1 and attend_id = 'ATD-2020-016559';

select * from ttadattendance where 1=1 and attend_id = 'ATD-2020-016559';
	
select * from ttadattendance  
where company_id = '13852' and attend_id = 'ATD-2020-016559' and attend_code = 'ABS' 

truncate table TCTDEMPABS5LOG;
show open tables where in_use <> 0 or name_locked <> 0;
select * from TCTDEMPABS5LOG;
select count(*) from TCTDEMPABS5LOG;

drop table TCTDEMPABS5LOG;

CREATE TABLE `TCTDEMPABS5LOG` (
  `period_code` varchar(50) DEFAULT NULL,
  `paydate` datetime(3) DEFAULT NULL,
  `emp_id` varchar(50) NOT NULL,
  `attendstartdate` datetime(3) DEFAULT NULL,
  `attendenddate` datetime(3) DEFAULT NULL,
  `absdatelist` varchar(55) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created_date` datetime(3) NOT null,
  KEY `idx_TCTDEMPABS5LOG` (`emp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

select 
emp_id, emp_no, full_name, u.user_name, 
start_date, end_date,
grade_code, grade_order, employ_code, cost_code,
position_id, pos_code,pos_name_en, pos_level, parent_path, 
dept_id,dept_code,
jobstatuscode, jobtitle_code, grade_category, worklocation_code,
is_main, empcompany_status,
gender, v.user_id, taxno, status, lastreqno, email, photo, phone, birthplace, birthdate, maritalstatus, address, company_id,   
spv_parent, spv_pos, spv_path, spv_level, mgr_parent, mgr_pos, mgr_path, mgr_level
-- personalarea_code, personalsubarea_code, payrollarea_code, employeegroup_code, customfield1
from view_employee v
inner join tclmuser u on u.user_id = v.user_id
where full_name like '%aan%' -- DO173237
-- where emp_id like '%DO1810697%'
-- where emp_no like '%%'
-- where user_id like '%%'
-- where user_name like '%%';

select * from TCTDINVALIDTIMESHEET where log_id = '77';
select * from teodempcustomfield t where emp_id = 'DO172449';

select distinct employ_code from view_employee ve;
select * from teomemploymentstatus t ;

select 
emp_id, emp_no, full_name, u.user_name, 
start_date, end_date,
grade_code, grade_order, employ_code, cost_code,
position_id, pos_code,pos_name_en, pos_level, parent_path, 
dept_id,dept_code,
jobstatuscode, jobtitle_code, grade_category, worklocation_code,
is_main, empcompany_status,
gender, v.user_id, taxno, status, lastreqno, email, photo, phone, birthplace, birthdate, maritalstatus, address, company_id,   
spv_parent, spv_pos, spv_path, spv_level, mgr_parent, mgr_pos, mgr_path, mgr_level
-- personalarea_code, personalsubarea_code, payrollarea_code, employeegroup_code, customfield1
from view_employee v
inner join tclmuser u on u.user_id = v.user_id
-- where full_name like '%%'
-- where emp_id like '%%'
where emp_no like '%0505002-O%'
-- where user_id like '%%'
-- where user_name like '%%';

select * from teodempcustomfield t where emp_id ='DO172054';

select sum(duration)
from tctdtimesheetcosting 
where 1=1
and tanggal between '2020-07-21' and '2020-08-20' and username = 'm.nurdin';

select *
from tctdtimesheetcosting 
where 1=1
and tanggal between '2020-07-21' and '2020-08-20'  
and username = 'm.nurdin'
order by tanggal;

select date_add(getdate(),interval -60 day);

update tclmuser 
set isreset = 2, last_login = now(), last_reset = now ();

select distinct table_name from information_schema.tables 
where table_name like '%leave%';
-- and table_schema like '%dev';

select * from ttadempgetleavedetail;


ttadempgetleave
ttadempgetleavedetail
ttadempgetleaveprocessdtl
ttadempleaveenttemp
ttadempleavegrade
ttadleavecancelrequest
ttadleavecancelrequestdetail
ttadleavemntlog
ttadleaverequest
ttadleaverequestdetail
ttadleaverequestdetailsts
ttadleaveschedulelog
ttadleaveunion
ttadmassiveleave
ttadmassiveleavedetail
ttamleaveent
ttamleavegrade
ttamleavetype
ttamleavetype20150227
ttarleaveemployee
ttarleaveentgrade
ttarleavetypeaddattcode
view_ai_leave
view_leave_balance_report
view_leave_new_report
view_leave_report
viewleavegrade
ttamleavetype_20150507
ttempgenleavefailed_demo
ttempgenleavefailed_system
leavetype