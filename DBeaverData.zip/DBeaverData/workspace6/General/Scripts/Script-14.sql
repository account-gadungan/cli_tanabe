select * from tctdtimesheetcosting t where username like '%raden%';

select * from tctdtimesheetcosting t where username like '%m.nurdin%' and month(tanggal)=7;

select chargecode , sum(duration) from tctdtimesheetcosting t 
where username in(
select (select customfield5 from teodempcustomfield t where emp_id = ve.emp_id) 
from view_employee ve where emp_no ='0505002-O'
-- from view_employee ve where emp_no ='6518002-ZEY'
)  
and tanggal between '2020-06-21 00:00:00' and '2020-07-20 00:00:00' 
group by chargecode ;

select count(*) from tctdtimesheetcosting;
select * from tctdtimesheetattendance_log order by log_id desc;
select * from tctdtimesheetcosting_log order by log_id desc;
select * from tpydprocmtdh where emp_id ='DO172220';

select * from tctdtimesheetattendance_log tl2 ; 

select * from tctexitemail where token = 'asdfhajklhfdklahdflhasdfhasdfh';


set @pdate = '2020-01-25';
select @pdate;
select * from teodemploymenthistory where emp_id = 'DO173237';

select *
from (select emp_id,effectivedt,emp_no from teodemploymenthistory
	where employmentstatus_code = 'permanent'
and UPPER(emp_id) = 'DO173237'
	order by effectivedt 
	limit 1) as t 
where effectivedt <= date_sub(@pdate,interval 1 year)
and (
	date_format(effectivedt, '%m-%d') between 
	date_format((select salarystartdate from ttadattintf where paydate=@pdate limit 1), '%m-%d') and 
	date_format((select salarystartdate from ttadattintf where paydate=@pdate limit 1), '%m-31') or
	date_format(effectivedt, '%m-%d') between 
	date_format((select salaryenddate from ttadattintf where paydate=@pdate limit 1), '%m-01') and 
	date_format((select salaryenddate from ttadattintf where paydate=@pdate limit 1), '%m-%d')
)
-- 	and date_format(effectivedt, '%m-%d') between 
-- 	date_format((select salarystartdate from ttadattintf where paydate=@pdate limit 1), '%m-%d') and 
-- 	date_format((select salaryenddate from ttadattintf where paydate=@pdate limit 1), '%m-%d') 
and mod(year(@pdate)-year(effectivedt),6) != 0
and (mod(year(@pdate)-year(effectivedt),6) != 1 or year(@pdate)-year(effectivedt) = 1 ) ;

select * from tpympayperiod t where paydate = @pdate;

select * from tclmdashodata ;
select * from tclddashodatakpi ;

select * from information_schema.`COLUMNS` c  where COLUMN_NAME like '%data_sour%';

select * from table;

SELECT * FROM Information_Schema.columns limit 10; 
where table_type = 'BASE TABLE' and table_schema = 'dbsf_nbc_enjiniring' order by table_name; 


select * from dbsf_nbc_enjiniring_training.bakup_config_21042020;
select * from bakup_config_21042020;

alter table bakup_config_21042020 add column wew1 int;

	CREATE TABLE bakup_config_21042020 ( [ID] INT , [LINK] VARCHAR (16384) , [REMARK] VARCHAR (16384) , [LSTFILE] VARCHAR (16384) , [WEW] INT );

SELECT TOP 1 IDENTITYCOL from bakup_config_21042020;
-- dbsf_nbc_enjiniring_training.bakup_config_21042020 definition

CREATE TABLE `wew` (
  `id` int(11) NOT NULL DEFAULT '0',
  `link` varchar(255) NOT NULL,
  `remark` varchar(255) NOT NULL,
  `lstfile` varchar(500) DEFAULT NULL,
  `wew` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE wewe (
  id int(11) NOT NULL DEFAULT '0',
  link varchar(255) NOT NULL,
  remark varchar(255) NOT NULL,
  lstfile varchar(500) DEFAULT NULL,
  wew int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- dbsf_nbc_enjiniring_training.tctdtimesheetattendance_log definition

CREATE TABLE `tctdtimesheetattendance_log` (
  `log_id` bigint(11) NOT NULL AUTO_INCREMENT,
  `ws_link` varchar(255) DEFAULT NULL,
  `created_date` datetime(3) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=latin1;

select * from dbsf_nbc_enjiniring_training.tctdtimesheetattendance_log;
select * from BAKUP_CONFIG_21042020;
alter table BAKUP_CONFIG_21042020 drop column wew1;

SELECT DISTINCT *
FROM Information_Schema.columns 
-- where UPPER(table_name) = 'ttadattendance'
where UPPER(table_name) = 'BAKUP_CONFIG_21042020'
and table_schema = 'dbsf_nbc_enjiniring_training'
Order by Ordinal_Position ;

SELECT DISTINCT TABLE_NAME,COLUMN_NAME,ORDINAL_POSITION,COLUMN_DEFAULT
,IS_NULLABLE,DATA_TYPE,CHARACTER_MAXIMUM_LENGTH
FROM Information_Schema.COLUMNS
where UPPER(table_name) = 'BAKUP_CONFIG_21042020'
Order by Ordinal_Position ;

-- dbsf_nbc_enjiniring_training.ttadattendance definition

CREATE TABLE `ttadattendance` (
  `attend_id` varchar(50) NOT NULL,
  `emp_id` varchar(50) NOT NULL,
  `shiftdaily_code` varchar(50) NOT NULL,
  `company_id` int(11) NOT NULL,
  `shiftstarttime` datetime(3) DEFAULT NULL,
  `shiftendtime` datetime(3) DEFAULT NULL,
  `attend_code` varchar(50) DEFAULT NULL,
  `starttime` datetime(3) DEFAULT NULL,
  `endtime` datetime(3) DEFAULT NULL,
  `actual_in` int(11) DEFAULT NULL,
  `actual_out` int(11) DEFAULT NULL,
  `daytype` varchar(5) NOT NULL,
  `ip_starttime` varchar(20) DEFAULT NULL,
  `ip_endtime` varchar(20) DEFAULT NULL,
  `remark` varchar(5000) DEFAULT NULL,
  `default_shift` varchar(1) NOT NULL,
  `total_ot` float DEFAULT NULL,
  `total_otindex` float DEFAULT NULL,
  `overtime_code` varchar(50) NOT NULL,
  `created_date` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `created_by` varchar(50) NOT NULL,
  `modified_date` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `modified_by` varchar(50) NOT NULL,
  `flexibleshift` varchar(1) DEFAULT NULL,
  `auto_ovt` int(11) DEFAULT NULL,
  `actualworkmnt` int(11) DEFAULT NULL,
  `geolocation` varchar(200) DEFAULT NULL,
  `photo_start` varchar(255) DEFAULT NULL,
  `photo_end` varchar(255) DEFAULT NULL,
  `geoloc_start` varchar(255) DEFAULT NULL,
  `geoloc_end` varchar(255) DEFAULT NULL,
  `actual_lti` int(11) DEFAULT NULL,
  `actual_eao` int(11) DEFAULT NULL,
  PRIMARY KEY (`attend_id`),
  KEY `IX_TTADATTENDANCE` (`emp_id`,`company_id`,`shiftstarttime`,`attend_id`,`shiftdaily_code`,`shiftendtime`,`attend_code`,`starttime`,`endtime`,`actual_in`,`actual_out`,`daytype`,`remark`(100),`default_shift`,`total_ot`,`total_otindex`,`auto_ovt`,`actualworkmnt`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


select * from information_schema.STATISTICS where TABLE_SCHEMA = 'dbsf_nbc_enjiniring' 
and TABLE_NAME = 'teomemppersonal'
order by TABLE_NAME, SEQ_IN_INDEX ; 

show index from ttadattendance;

select index_schema,
       index_name,
       group_concat(column_name order by seq_in_index) as index_columns,
       index_type,
       case non_unique
            when 1 then 'Not Unique'
            else 'Unique'
            end as is_unique,
        table_name
from information_schema.statistics
where table_schema not in ('information_schema', 'mysql',
                           'performance_schema', 'sys')
group by index_schema,
         index_name,
         index_type,
         non_unique,
         table_name
order by index_schema,
         index_name;
         
show index from teomemppersonal;

-- dbsf_nbc_enjiniring_training.teomemppersonal definition

CREATE TABLE `teomemppersonal` (
  `emp_id` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `gender` tinyint(4) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `taxno` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) DEFAULT NULL,
  `photo` varchar(100) DEFAULT NULL,
  `geocoord` varchar(50) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `req_status` tinyint(4) NOT NULL DEFAULT '1',
  `lastreqno` varchar(50) DEFAULT NULL,
  `created_date` datetime(3) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `modified_date` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `modified_by` varchar(50) NOT NULL,
  `official_name` varchar(255) DEFAULT NULL,
  `initial_name` varchar(50) DEFAULT NULL,
  `emp_image` varchar(255) DEFAULT NULL,
  `emp_signature` varchar(255) DEFAULT NULL,
  `full_name` varchar(302) DEFAULT NULL,
  `isent` tinyint(4) NOT NULL DEFAULT '0',
  `onboarding_completed` int(11) DEFAULT NULL,
  `local_name` varchar(500) DEFAULT NULL,
  `suffix_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`emp_id`),
  KEY `fk_teomemppersonal_tclmuser` (`user_id`),
  KEY `IDX_Employee_per` (`emp_id`),
  CONSTRAINT `fk_teomemppersonal_tclmuser` FOREIGN KEY (`user_id`) REFERENCES `tclmuser` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


select * from information_schema.REFERENTIAL_CONSTRAINTS;