select * from tsfmaccess t where access_code ='hrm.performance';
select * from tsfmfeature t2 where feat_id in (1,4,5,17,22,24,25,53,54,56,58,59,60,73,75);
select * from tsfclicense t ;
where access_code ='hrm.performance';

select * from teodcompanyreg t ;