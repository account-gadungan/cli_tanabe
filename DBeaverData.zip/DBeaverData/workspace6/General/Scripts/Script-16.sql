select * from tpympayallowdeduct t 


SELECT allowdeduct_code, company_id, allowdeductname_en, created_date, created_by, modified_date, modified_by, allowdeductname_id, allowdeductname_my, allowdeductname_th, allowdeducttype, taxed, taxclass, net, enabled, onpayslip, enable_backpay, currency_code, default_value, reset_value, allowdeduct_formula, process_order, effective_date, end_date, group_order, epf, socso, fixed, sss, philhealth, pagibig, alphalist, isprorated, allowdeduct_referer, costdash, CPF, SDL, hrdlevy, LIMIT_TYPE, EIS, editable_compresult, MPF, enable_prorate
FROM dbsf_nbc_bpkh2019.tpympayallowdeduct
where allowdeductname_en like '%jkk%';

select * from tclmuser where user_email;

select * from tpmdperiodkpilib;