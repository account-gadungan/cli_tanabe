select distinct table_name from information_schema.tables 
where table_name like '%mpp%';
-- and table_schema like '%dev';

select * from trcdmpp;
select * from trcdmppdetail where year(mppdetail_date) = 2021;

select mpp_code , mppdetail_date 
,(select pos_name_en from teomposition where position_id = d.position_id) as pos_name
,basedon_code_2, mpp_emp, actualemp_onrequest
from trcdmppdetail d where year(mppdetail_date) = 2021;

select * from teomposition t where pos_name_en like '%champ%';


select 
-- emp_id, 
emp_no, full_name, -- u.user_name, 
-- start_date, end_date,
grade_code, -- , grade_order
-- , employ_code, cost_code,
position_id, pos_code,pos_name_en, pos_level, parent_path, 
dept_id,dept_code,
jobstatuscode, jobtitle_code, grade_category, worklocation_code,
is_main, empcompany_status,
gender, v.user_id, taxno, status, lastreqno, email, photo, phone, birthplace, birthdate, maritalstatus, address, company_id,   
spv_parent, spv_pos, spv_path, spv_level, mgr_parent, mgr_pos, mgr_path, mgr_level
-- personalarea_code, personalsubarea_code, payrollarea_code, employeegroup_code, customfield1
from view_employee v
inner join tclmuser u on u.user_id = v.user_id
-- where full_name like '%%'
where position_id in (33804,33816,33828,33857,33863,33869,33930,33936,33989,33992,34086,34103,34118,34150,34160,34193,34196,34211,34238,34247,34250,34256,34268,34280,34342,34351,34382,34394,34451,34469,34484,34516,34530,34533,38268,38612,39135,39195,40113,40377,40755,42163,42164,42228,42236,42259,42291,42347,42354,42402,42436,42523,42558,42655,42665,42743,42760,42803,42809,42878)
and status = 1
order by position_id; 

select position_id, count(*) 
from teodempcompany t
where status = 1
group by position_id
having count(*) > 1;

select distinct mpp_code from trcdmppdetail;

select * from trcmmppperiod;

select * from teomposition t where position_id = 39195;
select * from teomposition t where position_id in (0,33390,39132,42199,42200,42803);

select * from trcmscreentype t ;
select * from trcmfiltercriteria;

-- delete from trcmfiltercriteria where code like '%maritalstatus%';

select * from teomposition t where pos_name_en like '%sr. manager : legal tech%';
select * from teomposition t where position_id in (0,33390,39393,42307);

select * from tcltrequest t where req_type like '%recruit%';

select 
emp_id, emp_no, full_name, u.user_name, 
start_date, end_date,
grade_code, grade_order, employ_code, cost_code,
position_id, pos_code,pos_name_en, pos_level, parent_path, 
dept_id,dept_code,
jobstatuscode, jobtitle_code, grade_category, worklocation_code,
is_main, empcompany_status,
gender, v.user_id, taxno, status, lastreqno, email, photo, phone, birthplace, birthdate, maritalstatus, address, company_id,   
spv_parent, spv_pos, spv_path, spv_level, mgr_parent, mgr_pos, mgr_path, mgr_level
-- personalarea_code, personalsubarea_code, payrollarea_code, employeegroup_code, customfield1
from view_employee v
inner join tclmuser u on u.user_id = v.user_id
-- where full_name like '%%'
where emp_id like '%DO172236%'
-- where emp_no like '%%'
-- where user_id like '%%'
-- where user_name like '%%';

select * from trcdmpplog t ;
select * from trcdmppdetail_history th;

select * from TRCDMPPDETAIL where mpp_code like 'MPP20210100124';
select * from TRCDMPPDETAIL where position_id = 43962;
select * from TRCDMPP;

select * from teomposition t where pos_code like '%tes%';
select * from teomcostcenter t ;
select * from teomworklocation t ;

select * from tclmaccessgroup t ;
select * from tclrgroupaccess t where usergroup_id = 24;
select * from tsfmaccess t where access_name_en like '%h3i%';

select distinct table_name from information_schema.tables 
where table_name like '%acc%';
-- and table_schema like '%dev';

select * from trcdrecruitreqquest t ;
select * from trcmrecruitreq t ;

select * from trcdapphistory t ;
select * from trcdapppersonal t ;

select * From tsfmmailtemplate;
select * From TRCMSELTYPE;

select * From TRCRAPPSEL where applicant_id = 'APL2021010776' order by order_no ;
select * From TRCDAPPSEL where applicant_id = 'APL2021010776';
select * From trcdapphistory where applicant_id = 'APL2021010776';

select * From trcdapphistory where applicant_id = 'APL2021010779';
select * From trcdapphistory where apphistory_code = 'APP20210100734';
select * From trcdapphistory where applicant_id = 'APL2021010779';
select * From TRCMRECRUITREQ;
select * from trcmapppersonal t where full_name like '%muad%';
select * from trcmapppersonal t where full_name like '%marc%';

select distinct table_name from information_schema.tables 
where table_name like 'trc%';
-- and table_schema like '%dev';


select * From trccappfield;
-- select * From trcdappaddress;
-- select * From trcdappadfield;
-- select * From trcdappcertification;
-- select * From trcdappcourse;
-- select * From trcdappcv;
-- select * From trcdappeducation;
-- select * From trcdappemergency;
-- select * From trcdappfamily;
-- select * From trcdapphistory;
-- select * From trcdappjobexp;
-- select * From trcdapplanguage;
-- select * From trcdappmedical;
-- select * From trcdappmedicalhistory;
-- select * From trcdapporgactivities;
select * From trcdapppersonal;
-- select * From trcdappprescreen;
-- select * From trcdappprescreentemp;
-- select * From trcdappref;
select * From trcdappsel;
select * From trcdappseltypelib;
select * From trcdappskill;
-- select * From trcdappvideoanswer;
select * From trcdmpp;
select * From trcdmpp_cobain;
select * From trcdmppdetail;
select * From trcdmppdetail_cobain;
select * From trcdmppdetail_history;
select * From trcdmppdetail_history_20190203_jnd;
select * From trcdmppdetail_history_cobain;
select * From trcdmpplog;
select * From trcdmpplog_20190203_jnd;
select * From trcdmpplog_cobain;
select * From trcdmpprequest;
select * From trcdmpprequestdetail;
select * From trcdrecruitreqadvert;
select * From trcdrecruitreqallow;
select * From trcdrecruitreqcoll;
select * From trcdrecruitreqformtemplate;
select * From trcdrecruitreqformtemplate_20190129;
select * From trcdrecruitreqformtemplatecategory;
select * From trcdrecruitreqformtemplatecategory_20190131_jnd;
select * From trcdrecruitreqopt;
select * From trcdrecruitreqpic;
select * From trcdrecruitreqquest;
select * From trcdrecruitreqselstep;
select * From trcdrecruitreqvideoquest;
select * From trcdscreentype;
select * From trcdscreentypeopt;
select * From trcdseltypeseries;
select * From trclappregister; --
select * From trcmadvertisecat;
select * From trcmadvertisemedia;
select * From trcmallowance;
select * From trcmapppersonal;
select * From trcmattachmentcategory;
select * From trcmcollaborator;
select * From trcmfiltercriteria;
select * From trcmfiltercriteria_20190122_jnd;
select * From trcmmppperiod;
select * From trcmpplog;
select * From trcmreccategory;
select * From trcmrecruitreq;
select * From trcmrecruitreq_20190114_jnd;
select * From trcmrecruitreqforminfo;
select * From trcmrecruitreqforminfo_20190129;
select * From trcmrecruitreqforminfocategory;
select * From trcmrecruitreqforminfocategory_20190131_jnd;
select * From trcmrecruitreqformtemplate;
select * From trcmscreentype;
select * From trcmseltype;
select * From trcmseltypelib;
select * From trcmseltypereason;
select * From trcmseltypeseries;
select * From trcrappemp;
select * From trcrapponline;
select * From trcrappsel;

select distinct column_name,table_name from information_schema.columns
where column_name like '%apphistory%';


select * From trcdapphistory;
select * From trcdappprescreen;
select * From trcdappsel;
select * From trcdappseltypelib;
select * From trcdappvideoanswer;
select * From trcrappsel;

select * From TRCMSELTYPE;
select * From TRCMRECRUITREQ;
select * From TRCMSELTYPESERIES;

select distinct table_name from information_schema.tables 
where table_name like '%menu%';
-- and table_schema like '%dev';



select * from tplt_tclmaccessgroup; -- function group default
select * from tplt_tclrgroupaccess; -- function tree default

select * from tsfmaccess order by created_date desc; -- security Access
select distinct module_code, feat_id from tsfmaccess; -- security Access
select * from tsfmmenu order by created_date desc; -- function tree default
select * from tclmaccessgroup; -- function group menu
select * from tclrdataaccess where datagroup_id = 3; -- function tree
select * from tclrgroupaccess; -- Authorized Group data


select * from tctmnotifquestion t where notif_code = 'exit_checklist' and iscat=0 order by quest_order;
