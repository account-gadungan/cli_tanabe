create procedure us()
begin
	
	declare done INT default false;
	declare x varchar(255);
	declare cur1 cursor for

	select user_name 
	from tclmuser 
	where 1=1 
	-- and user_name <> @company 
	and user_type <> 9 -- bukan superadmin
	and user_status = 1 
	and user_name not in (
		select user_name from tcltusersharing t where due_date > now()
	);	
	
	declare continue HANDLER for not found set done = true;
	
	set @user = '';
	set @company = (select company_code from teomcompany);

	open cur1;
	
		read_loop: loop
			fetch cur1 into x;
		
			if done then 
				leave read_loop;
			end if;
		
			INSERT INTO tcltusersharing
			(user_name, sharedto, status, duration, start_date, due_date, last_used, created_date)
			VALUES(x, @company, 1, 302, now(), date_add(now(),interval 14 day), NULL, CURRENT_TIMESTAMP(3));
			
			-- select x;
			
		end loop;

	close cur1;
	
	-- select @user;

end;

-- drop procedure us;
call us;
