CREATE TABLE if not exists `tpmdgoalcascading` (
  `cascadefrom_formno` varchar(50) NOT NULL,
  `cascadefrom_empid` varchar(50) NOT NULL,
  `cascadeto_formno` varchar(50) DEFAULT NULL,
  `cascadeto_empid` varchar(50) NOT NULL,
  `lib_code` varchar(50) NOT NULL,
  `lib_type` varchar(50) DEFAULT NULL,
  `target` float DEFAULT NULL,
  `company_code` varchar(50) DEFAULT NULL,
  `polarization` varchar(10) NOT NULL,
  `consolidation` varchar(10) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_by` varchar(50) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  PRIMARY KEY (`cascadefrom_formno`,`cascadefrom_empid`,`cascadeto_empid`,`lib_code`)
) ;

CREATE TABLE if not exists `tpmdperf_evalattachment` (
  `form_no` varchar(50) NOT NULL,
  `company_id` int(11) NOT NULL,
  `lib_type` varchar(10) NOT NULL,
  `reviewer_empid` varchar(50) NOT NULL,
  `reviewee_empid` varchar(50) NOT NULL,
  `period_code` varchar(50) NOT NULL,
  `file_attachment` varchar(255) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL
) ;

alter table TPMDPERFORMANCE_MIDV
add if not exists attachment_file varchar(500);

alter table TPMDPERFORMANCE_MIDV
add  if not exists is_verified varchar(1);


alter table tpmdperformance_evalh
add if not exists use_point integer;

CREATE TABLE if not exists `tpmdevald_comppoint` (
  `form_no` varchar(50) NOT NULL,
  `request_no` varchar(50) DEFAULT NULL,
  `comp_code` varchar(50) NOT NULL,
  `comp_type` varchar(1) DEFAULT NULL
) ;

alter table tpmdperformance_evald
modify column target varchar(2500);

alter table tpmdperformance_evald
modify column lib_name_en varchar(2500);

alter table tpmdperformance_evald
modify column lib_name_id varchar(2500);

alter table tpmdperformance_evald
modify column lib_name_my varchar(2500);

alter table tpmdperformance_evald
modify column lib_name_th varchar(2500);

alter table tpmdperformance_evald
modify column lib_desc_en varchar(2500);

alter table tpmdperformance_evald
modify column lib_desc_id varchar(2500);
alter table tpmdperformance_evald
modify column lib_desc_my varchar(2500);
alter table tpmdperformance_evald
modify column lib_desc_th varchar(2500);

alter table tpmdperformance_evald
modify column notes varchar(2500);

alter table tpmdperformance_evald
modify column achievement varchar(2500);
