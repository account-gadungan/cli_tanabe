SELECT p.Emp_id,
p.first_name,
p.Last_name,
p.middle_name,
c.start_date,
c.Emp_No,
c.Position_Id,
p.user_id,
ISNULL((

select top 1 jg.SERVICEPOINT from TEODEMPLOYMENTHISTORY h
left join TEOMJOBGRADE jg on jg.company_id=h.company_id and jg.grade_code=h.grade_code and jg.company_id=c.company_id
where effectivedt < '2020-02-29' and emp_id=p.emp_id order by effectivedt desc

), 0)
as SERVICEPOINT -- custom column
from teomemppersonal p, teodempcompany c, teomjobgrade g, tpydemppayfield pf
where c.company_id = 19242
and g.company_id=c.company_id
and p.emp_id = c.emp_id
and c.grade_code = g.grade_code
and p.emp_id = pf.emp_id
and (pf.payfield_no = 3 and (pf.value like '%SC%'))
AND c.Start_Date <= '2020-03-20'
AND (
c.End_Date is NULL OR
c.End_Date > '2020-02-01'
OR c.pay_through_date > '2020-03-31'
)
ORDER BY p.first_name,p.middle_name,p.Last_name,p.Emp_id 

select grade_code From TEODEMPLOYMENTHISTORY t where emp_id = 'DO192846';
select * from TEOMJOBGRADE where grade_code = '8';


select * from TPYDEMPSALARYPARAM t where company_id = 19243;

update TPYDEMPSALARYPARAM set formula = 'IIF(ACD EQ 0,0,IIF(ACD EQ TCD,IIF (ACDATT NEQ TCDATT AND ACDATT LTE 15 AND ACD NEQ TCD,ACDATT/TCDATT*SALARY,SALARY),ACD/TCD*SALARY))' where company_id = 19243;

select * from TEOMCOMPANY t ;