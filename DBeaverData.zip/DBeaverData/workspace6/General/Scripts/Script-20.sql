show create table TTADONDUTYREQUEST;

CREATE TABLE `ttadondutyrequest` (
  `request_no` varchar(50) NOT NULL,
  `company_id` int(11) NOT NULL,
  `requestedby` varchar(50) DEFAULT NULL,
  `requestfor` varchar(50) DEFAULT NULL,
  `requestdate` datetime(3) DEFAULT NULL,
  `purpose_code` varchar(50) NOT NULL,
  `total_destination` int(11) NOT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created_date` datetime(3) NOT NULL,
  `modified_by` varchar(50) NOT NULL,
  `modified_date` datetime(3) NOT NULL,
  `cancelsts` varchar(1) DEFAULT NULL,
  `upload_filename` varchar(255) DEFAULT NULL,
  `onduty_startdate` datetime DEFAULT NULL,
  `onduty_enddate` datetime DEFAULT NULL,
  PRIMARY KEY (`request_no`,`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1