select * from tctmreimnonbenefitposted order by modified_date desc;
select * from tctmcashbonposted order by modified_date desc;
select * from tctmondutyposted order by modified_date desc;

select * from tctmreimnonbenefitposted where paid is not null order by modified_date desc;
select * from tctmreimnonbenefitposted_log;
select * from tctmcashbonposted_log;
select * from tctmondutyposted_log;

select request_no,count(*) 
from tctmreimnonbenefitposted 
group by request_no
having count(*) > 0
order by modified_date desc;

show create table tctmondutyposted;

CREATE TABLE `tctmreimnonbenefitposted_log` (
  `request_no` varchar(100) NOT NULL,
  `posted` int(11) DEFAULT NULL,
  `cancel_status` int(11) DEFAULT NULL,
  `paid` int(11) DEFAULT NULL,
  `folder_path` varchar(255) DEFAULT NULL,
  `file_name` varchar(100) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `created_date` datetime DEFAULT null
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `tctmcashbonposted_log` (
  `request_no` varchar(100) NOT NULL,
  `posted` int(11) DEFAULT NULL,
  `cancel_status` int(11) DEFAULT NULL, 
  `folder_path` varchar(255) DEFAULT NULL,
  `file_name` varchar(100) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `tctmondutyposted_log` (
  `request_no` varchar(100) NOT NULL,
  `posted` int(11) DEFAULT NULL,
  `cancel_status` int(11) DEFAULT NULL,
  `paid` int(11) DEFAULT NULL,  
  `folder_path` varchar(255) DEFAULT NULL,
  `file_name` varchar(100) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `created_date` datetime DEFAULT null,
  PRIMARY KEY (`request_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- alter table TTADONDUTYREQUEST add column `onduty_startdate` datetime DEFAULT null;
-- alter table TTADONDUTYREQUEST add column `onduty_enddate` datetime DEFAULT null;
  
select * from TTADONDUTYREQUEST where upload_filename is not null;

select * from TTADONDUTYREQUESTdtl where request_no in (select request_no from TTADONDUTYREQUEST where upload_filename is not null);
select * from TTADONDUTYREQUESTdtl_atd where request_no in (select request_no from TTADONDUTYREQUEST where upload_filename is not null);
select * from TTADONDUTYREQUESTdtl_item where request_no in (select request_no from TTADONDUTYREQUEST where upload_filename is not null);

delete from TTADONDUTYREQUESTdtl_item where request_no in (select request_no from TTADONDUTYREQUEST where upload_filename is not null);
delete from TTADONDUTYREQUESTdtl_atd where request_no in (select request_no from TTADONDUTYREQUEST where upload_filename is not null);
delete from TTADONDUTYREQUESTdtl where request_no in (select request_no from TTADONDUTYREQUEST where upload_filename is not null);
delete from TTADONDUTYREQUEST where upload_filename is not null;

insert into
	TTADONDUTYREQUEST ( request_no, company_id, requestedby, requestfor, requestdate, purpose_code, total_destination, remark, created_by, created_date, modified_by, modified_date, upload_filename, onduty_startdate, onduty_enddate )
values ( 'ODR-2021-03-0021036', '13266', 'DO1712212', 'DO1712212', '2021-03-18', 'INTERNATIONAL', '1', 'wew', 'mariyono.mariyono', now(), 'mariyono.mariyono', now(), '2021/03/ODR-2021-03-0021036.jpg', '03/18/2021', '03/18/2021' );


sELECT a.*,
b.category_code,
category_name_en,
name_en
from
TTAMONDUTYALLOWITEM a
join TTAMONDUTYALLOWCAT b on
a.category_code = b.category_code
join TTAMODDESTINATION c on
c.code =(
select
	code
from
	TTAMODDESTINATION
where
	code like 'SOL')
where
a.category_code = 'MEAL_DOMESTIC'
and a.destination_code like 'SOL'
and not item_code = 'MEALDOMESTIC';

select * from TTAMODDESTINATION;