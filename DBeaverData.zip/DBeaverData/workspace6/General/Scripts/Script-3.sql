select * from tcltusersharing where user_name = ''; -- user_id

select * from tclmuser t  where;

select * from tclmuser t ;

update tclmuser set user_email = '';
update teomemppersonal set email = '';

select * from teomposition t where pos_name_en like '%head of%section';

select * from tpympayallowdeduct t where allowdeduct_formula like '%payfield6%';

select * from(
select position_id
,(select pos_name_en from teomposition where position_id = c.position_id)
,grade_code, count(*) 
from teodempcompany c
group by position_id , grade_code 
having count(*) > 1
) x 
where position_id in (442,473,477,479,512,516,552)

delete from tpydprocytdd; 
delete from tpydprocytdh; 
delete from tpydprocmtdd; 
delete from tpydprocmtdh;

update tclmuser set user_email = '';
update teomemppersonal set email = '';

GRANT ALL PRIVILEGES ON *.* TO 'sfnbc_mtindonesia_admin'@'%';

select * from view_employee ve ;

select * from tcltrequest t ;