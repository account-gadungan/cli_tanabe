SELECT *   FROM  

( 

	SELECT a.userid AS userid

	,(SELECT u.Badgenumber FROM userinfo u WHERE (u.userid=a.userid)) AS empno

	,CONVERT(VARCHAR(10),a.checktime,101) AS attend_date

	,CONVERT(VARCHAR(5),a.checktime,108) AS attend_time

	,a.timestamp AS timestamp

	FROM sf_attend_log a   

)x  

select * from USERINFO u ;