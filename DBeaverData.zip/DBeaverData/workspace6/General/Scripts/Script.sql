select * 
from teomemppersonal t
inner join tclmuser u on t.user_id = u.user_id;

select * from teomemppersonal t limit 100;
select enddate,count(*)
    from atttempquery t group by enddate;

select distinct table_name from information_schema.tables 
where table_name like '%decla%';
-- and table_schema like '%dev';
   
SELECT * FROM TTADONDUTYDECLARATION
WHERE request_no = 'DCLR-2019-12-0011467'

SELECT * FROM TTADONDUTYDECLARATION
WHERE request_no = 'DCLR-2019-12-0011192'



select * From tcltrequest t where req_no = 'DCLR-2019-12-0011193';

select * From ttadondutydeclarationdtl where request_no = 'DCLR-2019-12-0011193';

select * From ttadondutydeclarationdtl_atd where request_no = 'DCLR-2019-12-0011193';

select * From ttadondutydeclarationdtl_item where request_no = 'DCLR-2019-12-0011193';

select * From ttadondutyrequest where request_no like '0807/11/061/PLNE/2019%';
select * From ttadondutyrequestdtl_atd where request_no like '0807/11/061/PLNE/2019%';

select 
emp_id, emp_no, full_name, u.user_name, 
start_date, end_date,
grade_code, grade_order, employ_code, cost_code,
position_id, pos_code,pos_name_en, pos_level, parent_path, 
dept_id,dept_code,
jobstatuscode, jobtitle_code, grade_category, worklocation_code,
is_main, empcompany_status,
gender, v.user_id, taxno, status, lastreqno, email, photo, phone, birthplace, birthdate, maritalstatus, address, company_id,   
spv_parent, spv_pos, spv_path, spv_level, mgr_parent, mgr_pos, mgr_path, mgr_level
-- personalarea_code, personalsubarea_code, payrollarea_code, employeegroup_code, customfield1
from view_employee v
inner join tclmuser u on u.user_id = v.user_id
-- where full_name like '%%'
where emp_id like '%DO174616%'
-- where emp_no like '%%'
-- where user_id like '%%'
-- where user_name like '%%'
limit 100;

select * from tcltusersharing where user_name = '1612161-O' limit 100; -- user_id

select * from TRMMADDREIMFIELD limit 100;

select * from ttadondutyrequest t where requestedby like '%DO170797%' order by created_date desc limit 100;

delete from tcltrequest where req_no in (
	select request_no From ttadondutydeclaration where onduty_reqno like '%dclr%'
)

select * From ttadondutydeclaration where onduty_reqno like '%DCLR-2019-12-0011435%'

delete from tcltrequest where req_no in (select request_no from ttadondutydeclaration where onduty_reqno like '%dclr%')

select * from tcltrequest where req_no in('DCLR-2019-12-0011435')

select onduty_reqno from ttadondutydeclaration where onduty_reqno like '%dclr%' order by onduty_reqno desc


select t.requestfor as EMP_Id, (select `Full_Name` from view_employee where emp_id=t.requestfor) `Full_Name`,
t.request_no as ODT_DECLARATION_No, (select request_no from ttadondutyrequest where request_no=t.onduty_reqno and requestfor=t.requestfor) as ODT_REQ_No
,t.created_date,t.created_by as Created_By_EmpNo, (select `Full_Name` from view_employee where emp_no=t.created_by) as Created_By
from ttadondutydeclaration t where t.onduty_reqno='0127/12/061/PLNE/2019'

select * from ttadondutyrequest t limit 100;
select * from ttadleaverequest t

select distinct table_name from information_schema.tables 
where table_name like '%tct%';
-- and table_schema like '%dev';

select * from tctsppdjournallog.sent_data order by created_date desc limit 10;

DCLR-2019-12-0011692

select * from ttadondutyrequestdtl_atd ta where request_no ='0449/12/061/PLNE/2019'

select * from ttadondutyrequestdtl_atd ta where request_no ='0447/12/061/PLNE/2019'

select * from ttadondutydeclarationdtl_atd ta where request_no = 'DCLR-2019-12-0011692' limit 100;

select distinct table_name from information_schema.tables 
where table_name like '%perform%';
-- and table_schema like '%dev';

select distinct table_name from information_schema.tables 
where table_name like '%tct%';
-- and table_schema like '%dev';


select * From TEODEMPCOMPANYGROUP;

select * from TPYRPAYALLOWDEDUCTPERIOD;

select * FROM tpmdperformance_planh;

select distinct table_name from information_schema.tables 
where table_name like '%plan%';
-- and table_schema like '%dev';

select 
emp_id, emp_no, full_name, -- u.user_name, 
start_date, end_date,
grade_code, grade_order, employ_code, cost_code,
position_id, pos_code,pos_name_en, pos_level, parent_path, 
dept_id,dept_code,
jobstatuscode, jobtitle_code, grade_category, worklocation_code,
is_main, empcompany_status,
gender, v.user_id, taxno, status, lastreqno, email, photo, phone, birthplace, birthdate, maritalstatus, address, company_id,   
spv_parent, spv_pos, spv_path, spv_level, mgr_parent, mgr_pos, mgr_path, mgr_level
-- personalarea_code, personalsubarea_code, payrollarea_code, employeegroup_code, customfield1
from view_employee v
-- inner join tclmuser u on u.user_id = v.user_id
-- where full_name like '%%'
where emp_id like '%DO173237%'
-- where emp_no like '%%'
-- where user_id like '%%'
-- where user_name like '%%';

SELECT ph.period_code,ph.form_no,ph.reference_date,ph.request_no,ph.reviewee_posid, ph.reviewee_empid
FROM tpmdperformance_planh ph
inner join TPMMPERIOD p on ph.period_code = p.period_code
WHERE ph.reviewee_empid = 'DO1911347'
AND ph.reference_date < '2020-12-31 00:00:00'
AND ph.isfinal = 1
ORDER BY ph.reference_date DESC, ph.modified_date DESC
LIMIT 1 

SELECT ph.period_code,ph.form_no,ph.reference_date,ph.request_no,ph.reviewee_posid, ph.reviewee_empid
FROM tpmdperformance_planh ph
inner join TPMMPERIOD p on ph.period_code = p.period_code
WHERE ph.reviewee_empid = 'DO173237'
AND ph.reference_date < '2020-12-31 00:00:00'
AND ph.isfinal = 1
ORDER BY ph.reference_date DESC, ph.modified_date DESC
LIMIT 1 

select * From tpmdperformance_pland;
select * From tpmdperformance_plangen;

select * From tpmdperformance_plankpi;
select * From tpmdperformance_plannote;
delete From tpmdperformance_plannote;
delete From tpmdperformance_planh;
delete From tpmdperformance_pland;

select * from tpmmappraisal t 

select * From tpmdperformance_planrevised;

select distinct table_name from information_schema.tables 
where table_name like '%apprai%';
-- and table_schema like '%dev';

alter table tpmmappraisal add negative_component varchar(1) not null


show create table tpmmappraisal

CREATE TABLE `tpmmappraisal` (
  `appraisal_code` varchar(50) NOT NULL,
  `appraisal_name_en` varchar(255) DEFAULT NULL,
  `appraisal_name_id` varchar(255) DEFAULT NULL,
  `appraisal_name_my` varchar(255) DEFAULT NULL,
  `appraisal_name_th` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `appraisal_desc_en` varchar(500) DEFAULT NULL,
  `appraisal_desc_id` varchar(500) DEFAULT NULL,
  `appraisal_desc_my` varchar(500) DEFAULT NULL,
  `appraisal_desc_th` varchar(500) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `iscategory` varchar(1) NOT NULL,
  `appraisal_depth` int(11) NOT NULL,
  `parent_code` varchar(50) NOT NULL,
  `parent_path` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `order_no` int(11) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created_date` datetime(3) NOT NULL,
  `modified_by` varchar(50) NOT NULL,
  `modified_date` datetime(3) NOT NULL,
  `weight` float DEFAULT NULL,
  `achievement_type` varchar(50) DEFAULT NULL,
  `appraisal_name_vn` varchar(255) DEFAULT NULL,
  `appraisal_desc_vn` text,
  PRIMARY KEY (`appraisal_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1


select * from tpmmkpi where kpi_name_en like '%ppk%';
select distinct table_name from information_schema.tables 
where table_name like '%kpi%';
-- and table_schema like '%dev';

select emp_id , full_name , photo from teomemppersonal t ;

select distinct table_name from information_schema.tables 
where table_name like '%service%';
-- and table_schema like '%dev';

select * from tctmwebservice;

select 
emp_id, emp_no, full_name, u.user_name, 
start_date, end_date,
grade_code, grade_order, employ_code, cost_code,
position_id, pos_code,pos_name_en, pos_level, parent_path, 
dept_id,dept_code,
jobstatuscode, jobtitle_code, grade_category, worklocation_code,
is_main, empcompany_status,
gender, v.user_id, taxno, status, lastreqno, email, photo, phone, birthplace, birthdate, maritalstatus, address, company_id,   
spv_parent, spv_pos, spv_path, spv_level, mgr_parent, mgr_pos, mgr_path, mgr_level
-- personalarea_code, personalsubarea_code, payrollarea_code, employeegroup_code, customfield1
from view_employee v
inner join tclmuser u on u.user_id = v.user_id
where full_name like '%agus%'
-- where emp_id like '%%'
-- where emp_no like '%%'
-- where user_id like '%%'
-- where user_name like '%%';

select * from TPMMPERIOD;

select * from tpmdperformance_pland where form_no = 'PEF-2003-0106';
select reviewee_empid from tpmdperformance_planh where form_no = 'PEF-2003-0106' and isfinal = 1;




select * from tpmdperformance_evald where form_no = 'PEF-2003-0106'; 
select * from tpmdperformance_evalh where form_no = 'PEF-2003-0106'
and reviewee_empid = 'DO1911347'
and review_step = 0;

select score from tpmdperformance_evalh 
where form_no = f.form_no 
and reviewee_empid = f.reviewee_empid

	
select * from tpmdperformance_final where form_no = 'PEF-2003-0106';

select * from tpmdperformance_pland where form_no = 'PEF-2003-0106' 
and request_no = 'FM-PMPLAN-2004-0003' 
and reviewer_empid = 'DO170925';

select
(select emp_no from view_employee where emp_id = f.reviewee_empid) as NIK,
(select full_name from teomemppersonal where emp_id = f.reviewee_empid) as Nama,
d.lib_name_en as libname,
d.weight,
d.criteria,
d.target,
d.initiative,
d.scheduleplan,
d.actionresult,
(
	select format(score,1) from tpmdperformance_evalh 
	where form_no = f.form_no 
	and reviewee_empid = f.reviewee_empid
	and review_step = (
		select max(review_step)-2 from tpmdperformance_evalh 
		where form_no = f.form_no 
		and reviewee_empid = f.reviewee_empid
	) 
) as 'Score Assessee',
(
	select format(score,1) from tpmdperformance_evalh 
	where form_no = f.form_no 
	and reviewee_empid = f.reviewee_empid
	and review_step = 
	(
		select max(review_step)-1 from tpmdperformance_evalh 
		where form_no = f.form_no 
		and reviewee_empid = f.reviewee_empid
	) 
) as 'Score 1st Assesor',
(
	select format(score,1) from tpmdperformance_evalh 
	where form_no = f.form_no 
	and reviewee_empid = f.reviewee_empid
	and review_step = 
	(
		select max(review_step) from tpmdperformance_evalh 
		where form_no = f.form_no 
		and reviewee_empid = f.reviewee_empid
	) 
) as 'Score 2st Assesor'
,d.pointscriteria as 'Score Criteria'
,d.lib_code as libcode
-- PLD.lib_order
,d.form_no 
,f.period_code 
-- *
from tpmdperformance_final f 
inner join tpmdperformance_planh h on f.form_no = h.form_no 
inner join tpmdperformance_pland d on h.request_no = d.request_no 
	and h.isfinal = 1 
	and h.reviewer_empid = d.reviewer_empid 
where f.period_code = 'PERFPD20200300002'
-- order by libcode;


select
	*
from
	(
	select
		distinct ED.lib_name_en as libname,
		ED.weight,
		pld.criteria,
		ED.target,
		pld.initiative,
		pld.scheduleplan ,
		ed.actionresult ,
		ED.achievement as 'Score Assessee',
		ED.achievement as 'Score 1st Assesor',
		ED.achievement as 'Score 2st Assesor',
		pld.pointscriteria as 'Score Criteria',
		ED.lib_code as libcode,
-- 		ED.score,
-- 		ED.weightedscore,
-- 		ED.reviewer_empid,
-- 		ED.achievement_type as achscoretype,
		PLD.lib_order
		,EH.form_no 
		,f.period_code 
-- 		ED.lookup_code as lookupscoretype
	from tpmdperformance_final f
	left join TPMDPERFORMANCE_EVALH EH on f.form_no = EH.form_no 
	left join TPMDPERFORMANCE_EVALD ED on
		ED.form_no = EH.form_no
		and ED.company_code = EH.company_code
		and upper(ED.lib_type) = 'PERSKPI'
	left join TPMDPERIODKPILIB AP on
		ED.lib_code = AP.kpilib_code
		and EH.period_code = AP.period_code
		and ED.company_code = AP.company_code
	left join TPMDPERFORMANCE_PLAND PLD on
		PLD.lib_code = ED.lib_code
		and PLD.form_no = 'PEF-2003-0106'
		and PLD.reviewer_empid in ('DO170925')
		and PLD.request_no = 'FM-PMPLAN-2004-0003'
	where 1=1
	and f.period_code = 'PERFPD20200300002'
-- 		ED.reviewer_empid in ('DO171645')
-- 		and EH.period_code = 'PERFPD20200300002'
-- 		and EH.company_code = 'enjiniring'
-- 		and EH.request_no = 'CPM-2004-0008'
-- 		and EH.form_no = 'PEF-2003-0106' 
) tblperskpi
	
order by
	tblperskpi.lib_order;
	

select period_code,count(*) 
from(
	select distinct 
	(select allowdeducttype from tpympayallowdeduct where allowdeduct_code = t.allowdeduct_code ) as type, 
	allowdeduct_code, 
	(select allowdeductname_en from tpympayallowdeduct where allowdeduct_code = t.allowdeduct_code ) as name_en, 
	(select allowdeductname_id from tpympayallowdeduct where allowdeduct_code = t.allowdeduct_code ) as name_id,  
	period_code , currency_code , taxed 
	, taxclass , net, 
	(select onpayslip from tpympayallowdeduct where allowdeduct_code = t.allowdeduct_code ) as printonpayslip,
	allowdeduct_formula
	from tpydempallowdeduct t
) x
group by period_code;


select emp_id,
(
	select  sum(SF2356896(dd.COMP_VALUE_PERIOD, '46E1F37A2F88E1D1', '10011010100010011011', h.emp_id )) AS COMP_VALUE
	from tpydprocmtdd dd
	inner join tpydprocmtdh dh on dh.procmtdh_id = dd.procmtdh_id 
	where dh.emp_id = h.emp_id and dh.procmtdh_id = h.procmtdh_id and dd.allowdeducttype ='A'
) -
(
	select  sum(SF2356896(dd.COMP_VALUE_PERIOD, '46E1F37A2F88E1D1', '10011010100010011011', h.emp_id)) AS COMP_VALUE
	from tpydprocmtdd dd
	inner join tpydprocmtdh dh on dh.procmtdh_id = dd.procmtdh_id 
	where dh.emp_id = h.emp_id and dh.procmtdh_id = h.procmtdh_id and dd.allowdeducttype ='D'
) as Total
from tpydprocmtdh h
where h.period_code = 'organik' and paydate = '2020-05-25';


SELECT DATEDIFF(year, '2020/07/17', '2020/07/01') AS DateDiff;

select YEAR('2020/07/17') - YEAR('2020/07/17') - (DATE_FORMAT('2020/07/17', '%m%d') < DATE_FORMAT('2020/07/17', '%m%d')) as diff_years;
select YEAR('2020/07/17') - YEAR('2020/07/17');
select (DATE_FORMAT('2020/07/17', '%m%d') < DATE_FORMAT('2020/07/17', '%m%d')) as diff_years;

select (DATE_FORMAT('2020/07/17', '%m%d')) as diff_years;

select emp_id,effectivedt,emp_no 
from teodemploymenthistory 
where employmentstatus_code = 'permanent' 
and effectivedt <= date_sub("2020-07-25",interval 1 year)
-- and date_format(effectivedt, '%m-%d') between 
-- date_format((select salarystartdate from ttadattintf where paydate="2020-07-25" limit 1), '%m-%d') and 
-- date_format((select salaryenddate from ttadattintf where paydate="2020-07-25" limit 1), '%m-%d') 
-- and mod(year("2020-07-25")-year(effectivedt),6) != 0 
-- and (mod(year("2020-07-25")-year(effectivedt),8) != 0 or year("2020-07-25")-year(effectivedt) = 8);


create table so7749639 (date1 date, date2 date);
insert into so7749639 values
('2011-07-20', '2011-07-18'),
('2011-07-20', '2010-07-20'),
('2011-06-15', '2008-04-11'),
('2011-06-11', '2001-10-11'),
('2007-07-20', '2004-07-20');
select date1, date2,
YEAR(date1) - YEAR(date2)
    - (DATE_FORMAT(date1, '%m%d') < DATE_FORMAT(date2, '%m%d')) as diff_years
from so7749639;

SET @date1 := '2019-07-01';
SET @date2 := '2020-07-17';
SELECT TIMESTAMPDIFF(YEAR, @date1, @date2) AS difference;

SET @date3 := '2020-02-25';
select emp_id,effectivedt,emp_no
from teodemploymenthistory 
where employmentstatus_code = 'permanent' 
and effectivedt <= date_sub(@date3,interval 1 year)
and 
(
	date_format(effectivedt, '%m-%d') between 
	date_format((select salarystartdate from ttadattintf where paydate=@date3 limit 1), '%m-%d') and 
	date_format((select salarystartdate from ttadattintf where paydate=@date3 limit 1), '%m-31') or
	date_format(effectivedt, '%m-%d') between 
	date_format((select salaryenddate from ttadattintf where paydate=@date3 limit 1), '%m-01') and 
	date_format((select salaryenddate from ttadattintf where paydate=@date3 limit 1), '%m-%d')
)
and mod(year(@date3)-year(effectivedt),6) != 0 
and (mod(year(@date3)-year(effectivedt),8) != 0 or year(@date3)-year(effectivedt) = 8) and emp_id = 'DO170816'; 
order by effectivedt desc;

select distinct paydate from ttadattintf;
select * from teodemploymenthistory t where emp_id = 'DO170816' and employmentstatus_code = 'permanent' order by history_no;

select * from TCTDTIMESHEETATTENDANCE;
select * from tpydprocmtdh t ;

drop table tctdinvalidtimesheet;

CREATE TABLE `tctdinvalidtimesheet` (
  `ts_id` bigint(11) NOT NULL AUTO_INCREMENT,
  `duration` int(11) DEFAULT NULL,
  `nama_pegawai` varchar(50) DEFAULT NULL,
  `activity` varchar(255) DEFAULT NULL,
  `remark` varchar(900) DEFAULT NULL,
  `ts_date` datetime(3) NOT NULL,
  `projecttitle` varchar(255) DEFAULT NULL,
  `username` varchar(50) default NULL,
  `projectstage` varchar(255) DEFAULT NULL,
  `uploadstatus` int(11) DEFAULT NULL,
  `created_by` varchar(50) NOT NULL,
  `created_date` datetime(3) NOT NULL,
  `log_id` int(11) DEFAULT NULL,
  `type` varchar(10) not null,
  PRIMARY KEY (`ts_id`,`ts_date`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1

INSERT INTO TCTDINVALIDTIMESHEET (duration, nama_pegawai, activity, remark, ts_date, projecttitle, username, projectstage, uploadstatus, created_by, created_date, log_id, type) VALUES ( 8, 'Fuad Chariri', null, 'Vicon dengan Lapi ITB', {ts '2020-09-01 00:00:00'}, 'Non Project PPK', null, null, 0, 'enjiniring', {ts '2020-10-13 15:20:24'}, 70, 'attendance' )

select * from TCTDINVALIDTIMESHEET where log_id = '' ;

select * from tgecmasterdata;


select distinct table_name from information_schema.tables 
where table_name like '%data%';
-- and table_schema like '%dev';


select * from (
  select table_name, ExtractValue(record_key,'/RECORDKEY/history_no') pkey,
  activity_type, modified_date, 
  (select full_name from view_employee where emp_no = m.modified_by) modified_by_,
  field_name, old_value, new_value
  -- ,field_type
  -- ,record_key
  from TCLLMLOGACTIVITY m
  inner join TCLLdLOGACTIVITY d on d.log_header_id = m.log_header_id
  where table_name like '%teodemploymenthistory%'
  and d.field_name like 'grade_code'
) x
where pkey = 'CTL20190113057';

select * from TCLLdLOGACTIVITY;
select * from TCLLMLOGACTIVITY;

select * from dbsf6_saas_portal.tsfmaccess where access_id = 408;
select distinct module_code, feat_id from dbsf6_saas_portal.tsfmaccess order by module_code asc;
select * from dbsf6_saas_portal.tsfmfeature;
